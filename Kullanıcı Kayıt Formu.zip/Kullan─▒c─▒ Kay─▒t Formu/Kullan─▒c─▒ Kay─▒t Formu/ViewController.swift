//
//  ViewController.swift
//  Kullanıcı Kayıt Formu
//
//  Created by asdirector on 24.11.2023.
//

import UIKit

class ViewController: UIViewController {

    
    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var pasword: UITextField!
    
    @IBOutlet weak var paswordAgain: UITextField!
    
    @IBOutlet weak var mesutasLabel: UILabel!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func SignUpClick(_ sender: Any) {
        if username.text == "" {
            alertMessage(titleInput: "Error", messageInput: "Entery username!")
        } else if pasword.text == "" {
            alertMessage(titleInput: "Error", messageInput: "Entry Pasword!")
        }else if paswordAgain.text == "" {
            alertMessage(titleInput: "Error", messageInput: "Entry pasword again")
        }else if pasword.text != paswordAgain.text {
            alertMessage(titleInput: "Error", messageInput: "Entry same pasword!")
        }else {
            alertMessage(titleInput: "Success", messageInput: "User Ok")
        }
        
        
       
        
    }
    
    func alertMessage (titleInput: String, messageInput: String) {
        
        let alert = UIAlertController(title: titleInput, message: messageInput, preferredStyle: UIAlertController.Style.alert)
        let okButton = UIAlertAction(title: "Ok", style: UIAlertAction.Style.default)
        alert.addAction(okButton)
        self.present(alert, animated: true)
        
    }
}

